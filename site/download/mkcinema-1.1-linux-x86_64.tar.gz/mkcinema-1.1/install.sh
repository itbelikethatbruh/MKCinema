#!/bin/sh
# Installs MKCinema for this user (no sudo). Needs WebKitGTK 4.1: sudo apt install libwebkit2gtk-4.1-0, or sudo dnf install webkit2gtk4.1
set -e; cd "$(dirname "$0")"
mkdir -p ~/.local/bin ~/.local/lib/mkcinema ~/.local/share/applications ~/.local/share/icons/hicolor/512x512/apps
install -m755 mkcinema ~/.local/bin/mkcinema
install -m755 mkp2p ~/.local/lib/mkcinema/mkp2p
install -m644 mkcinema.png ~/.local/share/icons/hicolor/512x512/apps/mkcinema.png
sed "s|^Exec=mkcinema|Exec=$HOME/.local/bin/mkcinema|" mkcinema.desktop > ~/.local/share/applications/mkcinema.desktop
echo "MKCinema installed. Find it in your app menu, or run ~/.local/bin/mkcinema"
